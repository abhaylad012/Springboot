package com.demo.topic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TopicApplicationTests {

	@Test
	void contextLoads() {
	}

}
