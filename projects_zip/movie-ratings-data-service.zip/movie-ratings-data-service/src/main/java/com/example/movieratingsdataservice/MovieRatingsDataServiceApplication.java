package com.example.movieratingsdataservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieRatingsDataServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieRatingsDataServiceApplication.class, args);
	}

}
