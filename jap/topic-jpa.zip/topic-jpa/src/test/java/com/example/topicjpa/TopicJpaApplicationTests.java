package com.example.topicjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TopicJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
